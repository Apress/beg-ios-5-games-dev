//
//  ExampleController_iPad.h
//  Sample 06
//
//  Created by Lucas Jordan on 5/16/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ExampleController.h"

@interface ExampleController_iPad : ExampleController {
    
}

@end
