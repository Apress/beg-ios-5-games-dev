//
//  Sample_06AppDelegate_iPad.h
//  Sample 06
//
//  Created by Lucas Jordan on 5/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Sample_06AppDelegate.h"

@interface Sample_06AppDelegate_iPad : Sample_06AppDelegate {
    
}

@end
