//
//  Example03Controller.h
//  Sample 06
//
//  Created by Lucas Jordan on 5/18/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GameController.h"

@interface Example03Controller : GameController {
    
}
- (void)tapGesture:(UIGestureRecognizer *)gestureRecognizer;
@end
