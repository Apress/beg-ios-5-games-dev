//
//  Sample_03AppDelegate_iPad.m
//  Sample 03
//
//  Created by Lucas Jordan on 4/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Sample_03AppDelegate_iPad.h"

@implementation Sample_03AppDelegate_iPad

- (void)dealloc
{
	[super dealloc];
}

@end
