//
//  ViewController_iPhone.h
//  Sample 02
//
//  Created by Lucas Jordan on 9/13/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@interface ViewController_iPhone : ViewController

@end
