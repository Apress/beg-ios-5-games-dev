//
//  Sample_04AppDelegate_iPhone.m
//  Sample 04
//
//  Created by Lucas Jordan on 4/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Sample_04AppDelegate_iPhone.h"

@implementation Sample_04AppDelegate_iPhone

- (void)dealloc
{
	[super dealloc];
}

@end
