//
//  Sample_05AppDelegate_iPad.h
//  Sample 05
//
//  Created by Lucas Jordan on 4/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Sample_05AppDelegate.h"

@interface Sample_05AppDelegate_iPad : Sample_05AppDelegate {
    
}

@end
