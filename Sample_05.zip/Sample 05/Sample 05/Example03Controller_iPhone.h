//
//  Example03Controller_iPhone.h
//  Sample 05
//
//  Created by Lucas Jordan on 5/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Example03Controller.h"

@interface Example03Controller_iPhone : Example03Controller {
    
}

@end
