//
//  ViewController.h
//  Sample 11
//
//  Created by Lucas Jordan on 8/23/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{
    IBOutlet UIImageView* backgroundImageView;
}

@end
